const mysql = require('mysql2');


const conexion=mysql.createConnection({
    host:"localhost",
    user:"root",
    port:3306,
    password:"1234",
    database:"seminario",
})

conexion.connect((error)=>{
    if(error){
        console.error("Se presento un error"+error);
        return
    }
    console.log("Conexion Exitosa");


});

module.exports=conexion;