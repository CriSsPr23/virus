const express=require("express");
const router = express.Router(); 

const conexion=require("./database/db");

router.get("/cliente",(req,res)=>{
    conexion.query("select * from clientes",(error,resultado)=>{
         if(error){
            console.log(error);
            return
        }
        else{
            res.send(resultado);

        }


    });
});

router.get("/cliente2",(req,res)=>{
    conexion.query("select * from clientes",(error,resultado)=>{
         if(error){
            console.log(error);
            return
        }
        else{
            //res.send(resultado);
            //let hola="hola y adios";
            res.render("cliente/index",{clientes:resultado});

        }


    });
});

router.get("/crear",(req,res)=>{
  
            res.render("cliente/crear");

});

const metodos=require("./controller/me");
router.post("/save",metodos.save);


router.get("/editar/:id",(req,res)=>{
    const codigo=req.params.id;
    conexion.query("select *from clientes where codigo = ?",[codigo],(error,resultado)=>{
        if(error){
            console.log(error);
            return
        }
        else{
            //res.send(resultado);
            //let hola="hola y adios";
            res.render("cliente/editar",{clientes:resultado[0]});

        }
    })
});

router.post("/edit",metodos.edit);

router.get("/empleado",(req,res)=>{
    conexion.query("select * from empleado",(error,resultado)=>{
         if(error){
            console.log(error);
            return
        }
        else{
            res.send(resultado);

        }


    });
});


router.get("/empleado2",(req,res)=>{
    conexion.query("select * from empleado",(error,resultado)=>{
         if(error){
            console.log(error);
            return
        }
        else{
            //res.send(resultado);
            //let hola="hola y adios";
            res.render("empleado/index",{empleado:resultado});

        }


    });
});



router.get("/Empleados",(req,res)=>{
    res.send("Esta es la ruta de empleados");
})

router.get("/Empleados2",(req,res)=>{
    res.render("index");
})

module.exports=router;