const express=require("express");
const app=express();

app.set("view engine","ejs");

app.use(express.urlencoded({extended:false}));
app.use(express(express.json));

// app.get("/",(req,res)=>{
//    res.send("Este es un mensaje en la ruta");
// });

app.use("/",require("./router"));


app.listen(5000,()=>{
    console.log("Servidor local http://localhost:5000")
});